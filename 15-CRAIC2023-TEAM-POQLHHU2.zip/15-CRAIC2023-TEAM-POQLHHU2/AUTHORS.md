# Authors
---

The following people have been members of the UT Austin Villa RoboCup team and have directly or indirectly contributed to this codebase:

- Frank Barrera
- Samuel Barrett
- Yinon Bentor 
- Nick Collins
- Mike Depinet
- Josiah Hanna
- Todd Hester
- Shivaram Kalyanakrishnan
- Jason Liang
- Adrian Lopez-Mobilia 
- Patrick MacAlpine 
- Michael Quinlan 
- Art Richards 
- Andrew Sharp 
- Nicu Stiurca 
- Peter Stone 
- Daniel Urieli
- Victor Vu 